# NOTE: This code still works fine (end 2021), but commit history and english are questionable. I still accept issues & pull requests, don't be scared by last changed 3 years ago :)
# pigame
A touchscreen driver for the 2.8" capacitive.
## Docs
https://pigamedrv.github.io
