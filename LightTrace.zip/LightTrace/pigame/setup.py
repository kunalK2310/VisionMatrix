#!/usr/bin/env python
from setuptools import setup
setup(
# Name
name='pigame',
# Version
version='1.0',
# Desc
description='Raspberry Pi drivers.',
# We
author='PiGameDrv',
# Start Page
url='https://pigamedrv.github.io',
# Module
py_modules=['pigame']
)
