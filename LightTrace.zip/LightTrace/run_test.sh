#!/bin/bash

# Run the Python script with sudo
sudo /usr/bin/python3 /home/pi/LightTrace/game3.py
